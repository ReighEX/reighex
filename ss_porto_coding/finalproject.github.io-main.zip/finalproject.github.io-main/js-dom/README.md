# Javascript DOM

DOM = Document Object Modell

<!-- document.querySelector() -->