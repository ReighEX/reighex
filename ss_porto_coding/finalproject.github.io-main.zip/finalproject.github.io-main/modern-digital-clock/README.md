# digital-clock
Simple digital clock using jquery
